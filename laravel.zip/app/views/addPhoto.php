<!doctype html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
	<h1>Agregar foto</h1>	
	<form action="/photo" method="post">
	name: <input type="text" name="name"><br>
  	description: <input type="text" name="description"><br>
  	<button type="submit">Guardar</button>
	</form>
</body>
</html>