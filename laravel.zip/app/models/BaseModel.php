<?php
 class  BaseModel extends Eloquent
 {

 }