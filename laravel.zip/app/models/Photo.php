<?php
class Photo extends BaseModel
{

}